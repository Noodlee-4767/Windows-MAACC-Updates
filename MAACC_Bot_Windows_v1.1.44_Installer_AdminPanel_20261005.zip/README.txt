MAACC MINDSPARK BOT - WINDOWS INSTALLER v1.1.44
Python verification correction - 2026-10-03

1. Extract this ZIP completely into a new folder.
2. Double-click INSTALL_MAACC_BOT.cmd.
3. Keep internet connected and wait for setup to finish.
4. Open Mindspark Bot using its desktop or Start Menu shortcut.

You can rerun setup after the previous failed installation.
Do not uninstall Python first. Setup now correctly recognizes a working
Python that was installed by the previous attempt.

FIXED
Windows PowerShell could remove quotes from the Python verification command,
causing successful Python installations to be incorrectly rejected.
The verification command now uses compatible quoting. Store redirect aliases
are skipped, and automatic Python setup uses the winget repository directly.

SETUP
Setup verifies Python 3.10+ with venv, ensurepip and Tkinter, creates a private
runtime, and installs Playwright, openpyxl, Pillow and requests automatically.
The existing packaged bot, launcher, version and update behavior are unchanged.
Keep all extracted files together. This ZIP is under the 25 MB upload limit.

DIAGNOSTICS
If setup fails, open this folder by pasting it into File Explorer:
%LOCALAPPDATA%\MindsparkBot
Share installer.log and installer-python-check.log.

VALIDATION
Package integrity, Python syntax and the corrected verification command were
checked. A full Windows installation still needs testing on Windows.

Connect to Admin Panel in the bot using the one-time setup code.
